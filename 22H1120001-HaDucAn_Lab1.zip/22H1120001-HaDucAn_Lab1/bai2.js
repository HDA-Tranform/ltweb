var hoten="Nguyễn Văn Tèo";
var masv="PS123456";
var ngaysinh="2/1/2000"